/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package config;

/**
 *
 * @author Marilyn
 */
public class AppConstants {
     public static final String PATH_ARCHIVOS = "src/data/";
    public static final String SERIAL = PATH_ARCHIVOS +"eventos.dat";
    public static final String CSV = PATH_ARCHIVOS + "eventos.csv";
}
