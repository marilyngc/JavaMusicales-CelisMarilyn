/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.io.Serializable;
import java.time.LocalDate;
import service.CSVSerializable;

/**
 *
 * @author Marilyn
 */
public class EventoMusical extends Evento implements Comparable<EventoMusical>, CSVSerializable,Serializable{
   private static final long serialVersionUID = 1L; 
    private String artista;
    private GeneroMusical genero;


    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }


    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }


    @Override
    public String toString() {
        return super.toString() + 
                ", artista='" + artista + '\'' +
                ", genero=" + genero +
                '}';
    }

    
    @Override
    public int compareTo(EventoMusical otroEvento) {
        return this.getFecha().compareTo(otroEvento.getFecha());
    }

    @Override
    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," +   genero.toString();
    
    }
    
    
    public static EventoMusical fromCSV(String eventoMusicalCSV){
        
        if(eventoMusicalCSV.endsWith("\n")){
            eventoMusicalCSV = eventoMusicalCSV.substring(0, eventoMusicalCSV.length() - 1);
        }
            String[] valores = eventoMusicalCSV.split(",");
            
           
        int id = Integer.parseInt(valores[0]);
        String nombre = valores[1];
        LocalDate fecha = LocalDate.parse(valores[2]); 
        String artista = valores[3]; 
        GeneroMusical genero = GeneroMusical.valueOf(valores[4]); 

    return new EventoMusical(id, nombre, fecha, artista, genero); 
          
    }
}
