/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import model.Evento;
import model.EventoMusical;

/**
 *
 * @author Marilyn
 */
public class GestorEventos <T extends Evento & CSVSerializable>  {

    private List<T> items = new ArrayList<>();

    public void agregar(T item) {
         if (item == null) {
        throw new IllegalArgumentException("No se debe almacenar nulos.");
        }
        if (items.contains(item)) {
        throw new IllegalArgumentException("El elemento ya existe en el inventario.");
        }
        items.add(item);
    
    }
    
    public T obtenerElementos(int indice) {
        validarIndex(indice);
        return items.get(indice);   
    }
    

    
    public void eliminar(int indice) {
        validarIndex(indice);
        items.remove(indice);    }
    
    
    private void validarIndex(int indice){
        if(indice < 0 || indice >= items.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
            
        }
    }
    
    
    public void paraCadaElemento(Consumer<T> accion) {
        for (T item : items) {
            accion.accept(item);
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> aux = new ArrayList<>();
        for(T item : items){
            if(criterio.test(item)){
                aux.add(item);
            }
        }
        return aux;    }

    
    public void ordenar() {
       ordenar((Comparator<T>)Comparator.naturalOrder());
    }
    
  
    public void ordenar(Comparator<T> comparator) {
      if (items.isEmpty()) {
        throw new IllegalStateException("El inventario está vacío. No se puede ordenar.");
    }
        items.sort(comparator);
    }
    
    
    public List<T> buscarPorRangoDeFechas(LocalDate inicio, LocalDate fin) {
        return items.stream()
                .filter(e -> !e.getFecha().isBefore(inicio) && !e.getFecha().isAfter(fin))
                .collect(Collectors.toList());
    }
    
    
    
    public void serializar(String path) {
           // Crea los directorios si no existen
        File file = new File(path);
        file.getParentFile().mkdirs();

         try(ObjectOutputStream salida =  new ObjectOutputStream( new FileOutputStream(path))){
           
           salida.writeObject(items);
           System.out.println("Lista escrita en: " + path);
           System.out.println("Lista escrita");

           
       }catch (IOException  ex){
              ex.printStackTrace();
               }
    }
    
    public void deserializar(String path) {
        
           try(ObjectInputStream archivo =  new ObjectInputStream ( new FileInputStream(path))){
           
           items =(List<T>) archivo.readObject();
           
           System.out.println("Lista recuperado");

           
       }catch (IOException | ClassNotFoundException ex){
              ex.printStackTrace();
               }
    }
    
    
    public void guardarCSV(String path) {
                     try (BufferedWriter bw = new BufferedWriter(new FileWriter(path))) {
                    bw.write("id,nombre,fecha,titulo,genero\n");
            
            for(T item: items){
                bw.write(item.toCSV() + "\n");
            }
       
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("error perro");
        }
    }
    
    
    public void cargarCSV(String path, Function<String, T> funcion) {
                items.clear();
            try (BufferedReader bf = new BufferedReader(new FileReader(path))) {
            
             String linea;
                bf.readLine();
             while((linea = bf.readLine()) != null){
                 items.add(funcion.apply(linea));
             }
       
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
            throw new RuntimeException("error en archivo");
        }
    }
    
   

    
    @Override
    public String toString() {
        return "GestorEventos{" + "items=" + items + '}';
    }

  
    
    
    
    
}




