/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package musicales;

import static config.AppConstants.CSV;
import static config.AppConstants.SERIAL;
import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;
import model.Evento;
import model.EventoMusical;
import model.GeneroMusical;
import service.GestorEventos;

/**
 *
 * @author Marilyn
 */
public class Musicales {

    public static void main(String[] args) {

            GestorEventos<EventoMusical> gestor = new GestorEventos<>();
          // Crear algunos eventos musicales
        // Crear algunos eventos musicales
        gestor.agregar(new EventoMusical(1, "Rock Fest", LocalDate.of(2024, 3, 15),
        "Queen Revival", GeneroMusical.ROCK));
        gestor.agregar(new EventoMusical(2, "Jazz Night", LocalDate.of(2024, 6, 20),
        "John Doe Quintet", GeneroMusical.JAZZ));
        gestor.agregar(new EventoMusical(3, "Pop Party", LocalDate.of(2024, 8, 5),
        "Taylor Tribute", GeneroMusical.POP));
        gestor.agregar(new EventoMusical(4, "Electronic Vibes", LocalDate.of(2024, 10,
        12), "DJ Nova", GeneroMusical.ELECTRONICA));
        
        // Mostrar todos los eventos
        System.out.println("Lista inicial de eventos:");
        gestor.paraCadaElemento(evento -> System.out.println(evento));
        
 
 
        // Ordenar por fecha (orden natural)
        System.out.println("\nEventos ordenados por fecha:");
        gestor.ordenar();
        gestor.paraCadaElemento(evento -> System.out.println(evento));
 
        // Ordenar por nombre de evento
        System.out.println("\nEventos ordenados por nombre:");
        gestor.ordenar((e1, e2) -> e1.getNombre().compareTo(e2.getNombre()));
        gestor.paraCadaElemento(evento -> System.out.println(evento));
 
 
 
        // Filtrar por género
        System.out.println("\nEventos de género ROCK:");
        List<EventoMusical> rockEvents = gestor
          .filtrar(evento -> {
        if (evento == null) throw new IllegalArgumentException("evento nulo encontrado");
        return evento.getGenero() == GeneroMusical.ROCK;
            });
        rockEvents.forEach(evento -> System.out.println(evento));
        
 
        // Filtrar por palabra clave en el nombre
        System.out.println("\nEventos que contienen 'Night' en el nombre:");
        List<EventoMusical> nightEvents = gestor.filtrar((libro -> libro.getNombre().contains("Night")));
 
        nightEvents.forEach(System.out::println);
 
        // Buscar por rango de fechas
        System.out.println("\nEventos entre el 01/01/2024 y el 31/07/2024:");
        List<EventoMusical> dateRangeEvents = gestor.buscarPorRangoDeFechas(
        LocalDate.of(2024, 1, 1),
        LocalDate.of(2024, 7, 31)
        );
        dateRangeEvents.forEach(System.out::println);

        // Guardar y cargar en formato binario
        System.out.println("\nGuardando y cargando eventos en binario...");
        gestor.serializar(SERIAL);

        gestor.deserializar(SERIAL);
        gestor.paraCadaElemento(evento -> System.out.println(evento));

        // Guardar y cargar en formato CSV
        System.out.println("\nGuardando y cargando eventos en CSV...");
        gestor.guardarCSV(CSV);

        gestor.cargarCSV(CSV,linea -> EventoMusical.fromCSV(linea));
        gestor.paraCadaElemento(evento -> System.out.println(evento));

 
 
        // Filtrar eventos dinámicamente (artista contiene 'DJ')
        System.out.println("\nFiltrar eventos dinámicamente (artista contiene 'DJ'):");

        Predicate<EventoMusical> filtroArtista = evento -> {
         if (evento == null) throw new IllegalArgumentException("Evento nulo encontrado");
         return evento.getArtista().contains("DJ");  
        };
        List<EventoMusical> filtroDinamico = gestor.filtrar(filtroArtista);

        filtroDinamico.forEach(System.out::println);

    }
}
